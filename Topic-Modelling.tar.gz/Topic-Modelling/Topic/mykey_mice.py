from __future__ import absolute_import
from __future__ import print_function
import six
__author__ = 'a_medelyan'

import mykey
import operator
import io
import os

stoppath = "SmartStoplist.txt"

mykey_object = mykey.mykey(stoppath)

aList=[]
blist=[]
d={}
dict={}

indir='data/docs/fao_test'
for root,dirs,filenames in os.walk(indir):
	for f in filenames:
		if f.endswith('.key'):

			sample_file = io.open(os.path.join(root, f), 'r',encoding="iso-8859-1")
			text = sample_file.read()
			wordList = mykey.split_sentences(text)
			aList.append(wordList)
		
			f=f[0:len(f)-4]
			sample_file = io.open(os.path.join(root, f+".txt"), 'r',encoding="iso-8859-1")
			text = sample_file.read()
			keywords = mykey_object.run(text)
			blist.append(keywords)


myMap = map(None, aList, blist)




mykey_object = mykey.mykey(stoppath)

sample_file = io.open("input.txt", 'r',encoding="iso-8859-1")
text = sample_file.read()



# 1. Split text into sentences
sentenceList = mykey.split_sentences(text)

# for sentence in sentenceList:
#     print("Sentence:", sentence)

# generate candidate keywords
stopwordpattern = mykey.build_stop_word_regex(stoppath)
phraseList = mykey.generate_candidate_keywords(sentenceList, stopwordpattern)
#print("Phrases:", phraseList)

# calculate individual word scores
wordscores = mykey.calculate_word_scores(phraseList)

# generate candidate keyword scores
keywordcandidates = mykey.generate_candidate_keyword_scores(phraseList, wordscores)
# for candidate in keywordcandidates.keys():
# 	print("Candidate: ", candidate, ", score: ", keywordcandidates.get(candidate))

# sort candidates by score to determine top-scoring keywords
sortedKeywords = sorted(six.iteritems(keywordcandidates), key=operator.itemgetter(1), reverse=True)
totalKeywords = len(sortedKeywords)

# for example, you could just take the top third as the final keywords
frequ=[]
myfrequ=[]
for keyword in sortedKeywords[0:int(totalKeywords)]:
    #print("Keyword: ", keyword[0], ", score: ", keyword[1])
    frequ=[]
    for var in blist:
    	f1=mykey.calculate_freq_kw_corpus(keyword[0],var)
    	frequ.append(f1)
	myfrequ.append(frequ)
# print(len(sortedKeywords[0:int(totalKeywords / 3)]))
# print(len(myfrequ))
# print(myfrequ[0])
sumL=[]
sumL = [0 for x in range(len(frequ))]
for i in range(len(myfrequ)) :
	for j in range(len(myfrequ[i])):
		sumL[j]=sumL[j]+myfrequ[i][j]
# print(sumL)

index, value = max(enumerate(sumL), key=operator.itemgetter(1))
# print(index)

l1=myMap[index][0]
l3=[item[0] for item in sortedKeywords[0:int(totalKeywords )]]
l2=[item[0] for item in sortedKeywords[0:int(totalKeywords /3)]]
if totalKeywords <= 2:
	print(l1+l3)
else:
	print(l1+l2)

#print(mykey_object.run(text))

	